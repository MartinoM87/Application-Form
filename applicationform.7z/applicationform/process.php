<?php
require('config.php');
$db = mysqli_connect('localhost', 'root', '', 'applicationform');

if($_POST){

	$firstname 		= $_POST['firstname'];
	$lastname 		= $_POST['lastname'];
	$age 			= $_POST['age'];
	$email 			= $_POST['email'];
	$phonenumber	= $_POST['phonenumber'];
	$filepdf		= $_POST['filepdf'];


	$sql = "INSERT INTO users (firstname, lastname, age, email, phonenumber, filepdf) VALUES 
						('$firstname', '$lastname', '$age', '$email', '$phonenumber', '$filepdf')";
		
		mysqli_query($db,$sql);
}else{
	echo 'No data';
}

?>