<?php 

$db_user = 'root';
$db_pass = '';
$db_name = 'applicationform';

$conn = new mysqli('localhost',$db_user,$db_pass,$db_name) or die("unable to connect");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
